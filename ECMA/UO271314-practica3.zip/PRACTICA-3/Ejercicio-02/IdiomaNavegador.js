// Llama método -> escribe en document (Objeto) el idioma del navegador
document.write("<h2>")
document.write("Idioma del navegador: ")
document.write(infoNav.idioma)
document.write("</h2>")