// Llama método -> escribe en document (Objeto) el nombre del navegador.
document.write("<h1>")
document.write("Nombre navegador: ")
document.write(infoNav.nombre)
document.write("</h1>")