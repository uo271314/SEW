// Llama método -> escribe en document (Objeto) cursoActual, nombreEstudiante y emailProfesor en párrafos.
document.write("<p> Curso actual: ");
document.write(asignatura.cursoActual);
document.write("</p>");
document.write("<p> Nombre estudiante: ");
document.write(asignatura.nombreEstudiante);
document.write("</p>");
document.write("<p> Email profesor: ");
document.write(asignatura.emailProfesor);
document.write("</p>");