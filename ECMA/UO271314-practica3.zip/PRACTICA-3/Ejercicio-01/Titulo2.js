// Llama método -> escribe en document (Objeto) el nombre de la titulacion en un encabezada de nivel 2.
document.write("<h2>");
document.write(asignatura.nombreTitulacion);
document.write("</h2>");