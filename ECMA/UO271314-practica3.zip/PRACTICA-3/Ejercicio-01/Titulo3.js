// Llama método -> escribe en document (Objeto) el nombre del centro en un encabezado de nivel 3.
document.write("<h3>");
document.write(asignatura.nombreCentro);
document.write("</h3>");