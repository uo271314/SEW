// Llama método -> escribe en document el nombre de la universidad en un encabezado de nivel 4.
document.write("<h4>");
document.write(asignatura.nombreUniversidad);
document.write("</h4>");