// Contiene objeto -> nombre asignatura, nombre titulación, nombre centro, nombre universidad, curso actual, nombre estudiante, email
var asignatura = new Object();
asignatura.nombre = "SEW: Software y estándares en la Web";
asignatura.nombreTitulacion = "Grado en Ingeniería Informática del Software";
asignatura.nombreCentro = "Escuela de Ingeniería Informática";
asignatura.nombreUniversidad = "Universidad de Oviedo";
asignatura.cursoActual = "2020-2021";
asignatura.nombreEstudiante = "Laura Delgado Álvarez";
asignatura.emailProfesor = "cueva@uniovi.es";