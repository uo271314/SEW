// Llama a método -> escribe en document (Objeto) el nombre de la asignatura en un encabezada de nivel 1
document.write("<h1>");
document.write(asignatura.nombre);
document.write("</h1>");